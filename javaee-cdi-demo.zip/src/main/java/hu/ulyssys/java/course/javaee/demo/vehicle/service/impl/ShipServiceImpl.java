package hu.ulyssys.java.course.javaee.demo.vehicle.service.impl;

import hu.ulyssys.java.course.javaee.demo.vehicle.entity.Ship;
import hu.ulyssys.java.course.javaee.demo.vehicle.service.ShipService;

import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class ShipServiceImpl extends AbstractServiceImpl<Ship> implements ShipService {

}
