package hu.ulyssys.java.course.javaee.demo.vehicle.service;

import hu.ulyssys.java.course.javaee.demo.vehicle.entity.Ship;

public interface ShipService extends CoreService<Ship>{

}
