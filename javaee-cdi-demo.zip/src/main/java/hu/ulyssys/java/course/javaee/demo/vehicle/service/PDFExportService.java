package hu.ulyssys.java.course.javaee.demo.vehicle.service;

public interface PDFExportService {

    void processExport();
}
