package hu.ulyssys.java.course.javaee.demo.vehicle.entity;
//Egy enum értkenke, lehetnek plussz paraméterei, metódusai is.
public enum VehicleType {
    PLANE, SHIP, CAR
}
