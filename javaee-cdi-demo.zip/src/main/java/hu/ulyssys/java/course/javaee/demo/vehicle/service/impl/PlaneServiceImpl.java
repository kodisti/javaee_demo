package hu.ulyssys.java.course.javaee.demo.vehicle.service.impl;

import hu.ulyssys.java.course.javaee.demo.vehicle.entity.Plane;
import hu.ulyssys.java.course.javaee.demo.vehicle.service.PlaneService;

import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class PlaneServiceImpl extends AbstractServiceImpl<Plane> implements PlaneService {

}
