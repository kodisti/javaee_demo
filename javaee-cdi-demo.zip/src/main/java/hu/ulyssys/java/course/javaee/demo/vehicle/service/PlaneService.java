package hu.ulyssys.java.course.javaee.demo.vehicle.service;

import hu.ulyssys.java.course.javaee.demo.vehicle.entity.Plane;

public interface PlaneService extends CoreService<Plane>{

}
