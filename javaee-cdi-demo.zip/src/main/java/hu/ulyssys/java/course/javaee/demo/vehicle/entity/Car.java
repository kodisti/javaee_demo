package hu.ulyssys.java.course.javaee.demo.vehicle.entity;

public class Car extends AbstractVehicle  {

    private String licensePlateNumber;
    private int doorNumbers;

    //erre csak akkor van szükség, ha van olyan konsttuktor, aminek van bemenő paramétere. Ez az üres konstruktor
    public Car() {
    }

    public Car(Long id, String licensePlateNumber, String manufacturer, String type, int doorNumbers) {
        super(id, manufacturer, type);
        this.licensePlateNumber = licensePlateNumber;
        this.doorNumbers = doorNumbers;
    }

    public String getLicensePlateNumber() {
        return licensePlateNumber;
    }

    public void setLicensePlateNumber(String licensePlateNumber) {
        this.licensePlateNumber = licensePlateNumber;
    }

    public int getDoorNumbers() {
        return doorNumbers;
    }

    public void setDoorNumbers(int doorNumbers) {
        this.doorNumbers = doorNumbers;
    }

    @Override
    public VehicleType getVehicleType() {
        return VehicleType.CAR;
    }
}
