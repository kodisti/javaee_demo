package hu.ulyssys.java.course.javaee.demo.vehicle.service.impl;

import hu.ulyssys.java.course.javaee.demo.vehicle.entity.Car;
import hu.ulyssys.java.course.javaee.demo.vehicle.service.CarService;

import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class CarServiceImpl extends AbstractServiceImpl<Car> implements CarService {

}
